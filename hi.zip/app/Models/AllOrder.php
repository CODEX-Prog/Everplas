<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AllOrder extends Model
{
    protected $table = "all_job_orders";
}
